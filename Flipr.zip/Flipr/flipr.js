const apiUrl = "https://google-translate1.p.rapidapi.com/language/translate/v2";

const apiKey = "YOUR_RAPIDAPI_KEY"; 
const apiHost = "google-translate1.p.rapidapi.com";

const sourceLangSelect = document.getElementById('source-lang');
const targetLangSelect = document.getElementById('target-lang');
const inputText = document.getElementById('input-text');
const translateBtn = document.getElementById('translate-btn');
const translatedText = document.getElementById('translated-text');

fetch("https://google-translate1.p.rapidapi.com/language/translate/v2/languages", {
  "method": "GET",
  "headers": {
    "x-rapidapi-key": apiKey,
    "x-rapidapi-host": apiHost
  }
})
.then(response => response.json())
.then(data => {
  const languages = data.data.languages;
  languages.forEach(language => {
    const option = document.createElement('option');
    option.value = language.language;
    option.text = language.name;
    sourceLangSelect.appendChild(option);
    targetLangSelect.appendChild(option.cloneNode(true));
  });
})
.catch(err => console.error(err));

translateBtn.addEventListener('click', () => {
  const sourceLang = sourceLangSelect.value;
  const targetLang = targetLangSelect.value;
  const text = inputText.value;

  fetch(${apiUrl}?q=${encodeURIComponent(text)}&source=${sourceLang}&target=${targetLang}, {
    "method": "GET",
    "headers": {
      "x-rapidapi-key": apiKey,
      "x-rapidapi-host": apiHost
    }
  })
  .then(response => response.json())
  .then(data => {
    const translation = data.data.translations[0].translatedText;
    translatedText.textContent = translation;
    translatedText.parentElement.style.display = 'block';
  })
  .catch(err => console.error(err));
});